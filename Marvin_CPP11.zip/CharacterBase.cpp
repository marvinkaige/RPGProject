#include "CharacterBase.h"

CharacterBase::CharacterBase(Texture2D texture, int numSprites) : animation(texture, numSprites) {
}



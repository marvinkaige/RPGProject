#include "AActor.h"

Vector2 AActor::getPosition() {
	return position;
}

void AActor::setPosition(Vector2 newPosition) {
	position = newPosition;
};
